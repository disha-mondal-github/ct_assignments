# Indian Legal System RAG Chatbot with Web Search

A comprehensive Retrieval-Augmented Generation (RAG) chatbot for the Indian legal system that combines static legal documents with real-time web search capabilities. Built with LlamaIndex, Mistral AI, and Streamlit.

## 🚀 Key Features

- **Hybrid Intelligence**: Combines statutory documents with real-time web search
- **Smart Query Detection**: Automatically determines when to search for recent information
- **Document Processing**: Supports PDF, DOCX, and TXT formats
- **Web Scraping**: Searches trusted legal sources for latest cases and judgments
- **Intelligent Retrieval**: Uses vector similarity search for relevant legal information
- **Mistral AI Integration**: Powered by advanced language models
- **Legal-Specific Prompting**: Custom prompts tailored for legal queries with web context
- **Interactive UI**: Clean Streamlit interface with chat history
- **Trusted Sources**: Scrapes from IndianKanoon, LiveLaw, Bar & Bench, and official court websites

## Setup Instructions

### 1. Clone and Install Dependencies

```bash
git clone <your-repo-url>
cd indian-legal-chatbot
pip install -r requirements.txt
```

### 2. Get Mistral API Key

1. Visit [Mistral AI Platform](https://console.mistral.ai/)
2. Create an account and get your API key
3. Copy the API key for the next step

### 3. Configure Environment Variables

Create a `.env` file in the project root:

```bash
MISTRAL_API_KEY=your_mistral_api_key_here
```

### 4. Add Legal Documents

Create a `documents` folder in the project root and add your legal documents:

```
documents/
├── indian_constitution.pdf
├── indian_penal_code.pdf
├── crpc.pdf
├── cpc.pdf
├── indian_evidence_act.pdf
└── contract_act.pdf
```

**Recommended Documents:**
- Indian Constitution (1950)
- Indian Penal Code (IPC) 1860
- Code of Criminal Procedure (CrPC) 1973
- Code of Civil Procedure (CPC) 1908
- Indian Evidence Act 1872
- Contract Act 1872
- Transfer of Property Act 1882
- Companies Act 2013
- Consumer Protection Act 2019
- Information Technology Act 2000
- Right to Information Act 2005

### 5. Run the Application

```bash
streamlit run app.py
```

The application will be available at `http://localhost:8501`

## Project Structure

```
indian-legal-chatbot/
├── app.py                 # Main Streamlit application with web search UI
├── legal_chatbot.py       # Enhanced chatbot logic with web integration
├── document_processor.py  # Document processing utilities
├── web_scraper.py         # Web scraping for recent legal information
├── requirements.txt       # Python dependencies (includes web scraping libs)
├── .env                  # Environment variables (create this)
├── README.md             # This file
└── documents/            # Folder for legal documents (create this)
    ├── constitution.pdf
    ├── ipc.pdf
    └── ...
```

## 🔍 How Web Search Works

The chatbot intelligently determines when to search the web:

**Triggers Web Search When Query Contains:**
- "recent", "latest", "new", "2024", "2023", "current"
- "recent case", "latest judgment", "new law"
- Time-sensitive legal queries

**Trusted Legal Sources:**
- IndianKanoon.org
- Supreme Court website (main.sci.gov.in)
- LiveLaw.in
- Bar & Bench
- The Leaflet
- Legal news platforms

**Search Process:**
1. Detects if query needs recent information
2. Searches Google with legal-specific terms
3. Scrapes content from trusted sources only
4. Combines with statutory document context
5. Provides comprehensive, up-to-date responselamaIndex
4. **Query Processing**: When users ask questions, the system:
   - Retrieves relevant document chunks using similarity search
   - Sends the context and query to Mistral AI
   - Returns a comprehensive answer with legal context

## Usage Examples

### Sample Questions You Can Ask:

**Statutory Law Questions:**
- "What is Article 21 of the Indian Constitution?"
- "Explain the concept of bail under CrPC"
- "What are the essential elements of a contract under Indian law?"
- "What is the punishment for theft under IPC?"

**Recent Cases & Developments:**
- "Recent Supreme Court judgments on bail"
- "Latest cases on Article 370"
- "2024 criminal law amendments"
- "Current GST law updates"
- "Recent divorce law changes"
- "Latest judgments on fundamental rights"

**Mixed Queries:**
- "How has the interpretation of Article 14 evolved in recent cases?"
- "What are the latest developments in cybercrime law?"
- "Recent Supreme Court views on environmental protection"

## Customization

### Modifying Web Search Behavior

Edit web search triggers in `legal_chatbot.py`:

```python
def should_search_web(self, question: str) -> bool:
    web_search_keywords = [
        'recent', 'latest', 'new', '2024', '2023', 'current',
        # Add your custom keywords here
    ]
    return any(keyword in question.lower() for keyword in web_search_keywords)
```

### Adding Trusted Sources

Modify trusted sources in `web_scraper.py`:

```python
self.trusted_sources = [
    'indiankanoon.org',
    'main.sci.gov.in',
    'livelaw.in',
    # Add your trusted legal sources
]
```

### Adjusting Search Parameters

Modify these parameters in `web_scraper.py`:

```python
num_results = 5              # Number of web results to fetch
content_length = 3000        # Max content length per source
search_delay = 2             # Delay between searches (seconds)
```

### Adjusting Retrieval Parameters

Modify these parameters in `legal_chatbot.py`:

```python
Settings.chunk_size = 1024      # Size of text chunks
Settings.chunk_overlap = 200    # Overlap between chunks
similarity_top_k = 5            # Number of relevant chunks to retrieve
```

### Adding New Document Types

Extend the `DocumentProcessor` class to support additional file formats.

## Deployment

### Local Deployment
```bash
streamlit run app.py
```

### Cloud Deployment (Streamlit Cloud)

1. Push your code to GitHub
2. Go to [Streamlit Cloud](https://streamlit.io/cloud)
3. Connect your GitHub repository
4. Add your `MISTRAL_API_KEY` in the secrets management
5. Deploy!

### Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8501

CMD ["streamlit", "run", "app.py", "--server.port=8501", "--server.address=0.0.0.0"]
```

## Important Notes

1. **API Costs**: Monitor your Mistral API usage as it's a paid service
2. **Web Scraping Ethics**: The system respects robots.txt and includes delays
3. **Source Verification**: Always verify web-scraped information independently
4. **Rate Limiting**: Includes random delays to avoid being blocked
5. **Document Quality**: Ensure legal documents are clean and well-formatted
6. **Performance**: Initial setup may take time due to document processing and indexing
7. **Web Dependencies**: Requires stable internet connection for recent case queries
8. **Legal Accuracy**: Web-scraped content should be cross-verified with official sources

## Troubleshooting

### Common Issues:

1. **No documents found**: Ensure the `documents` folder exists and contains legal documents
2. **API key error**: Check that your Mistral API key is correctly set in the `.env` file
3. **Web scraping failures**: Check internet connection and try again
4. **Search blocked**: If Google blocks searches, wait and try later
5. **Memory issues**: For large documents, consider increasing chunk size
6. **Slow responses**: Web searches add processing time - normal for recent queries
7. **Content extraction errors**: Some websites may block scraping - this is normal

### Performance Tips:

- **For faster responses**: Ask about established law (no web search needed)
- **For recent information**: Use keywords like "recent", "latest", "2024"
- **Mixed queries**: System intelligently combines both sources
- **Source reliability**: Web information is filtered through trusted legal sources only

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is for educational purposes. Ensure you have the right to use any legal documents you include.

## Disclaimer

This chatbot provides general legal information and recent case updates for educational purposes only. 
Web-scraped information is sourced from trusted legal websites but should be independently verified. 
This is not a substitute for professional legal advice. Always consult with a qualified lawyer for 
legal matters specific to your situation. Ensure you have the right to use any legal documents you include.